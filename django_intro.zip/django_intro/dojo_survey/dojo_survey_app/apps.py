from django.apps import AppConfig


class DojoSurveyAppConfig(AppConfig):
    name = 'dojo_survey_app'
