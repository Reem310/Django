from django.apps import AppConfig


class TimeStampAppConfig(AppConfig):
    name = 'time_stamp_app'
