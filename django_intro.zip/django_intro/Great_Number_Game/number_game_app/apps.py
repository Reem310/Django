from django.apps import AppConfig


class NumberGameAppConfig(AppConfig):
    name = 'number_game_app'
